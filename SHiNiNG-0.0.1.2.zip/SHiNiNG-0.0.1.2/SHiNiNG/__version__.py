#   _____ _    _ _ _   _ _ _   _  _____
#  / ____| |  | (_) \ | (_) \ | |/ ____|
# | (___ | |__| |_|  \| |_|  \| | |  __
#  \___ \|  __  | | . ` | | . ` | | |_ |
#  ____) | |  | | | |\  | | |\  | |__| |
# |_____/|_|  |_|_|_| \_|_|_| \_|\_____|
#
#    -- * Lan-Yixiao * Eathoublu * --
#          -- Source Code NLP --
#
#  The easiest and powerful deep-learning-text-classifier
#  For human beings and all purposes.

VERSION = (0, 0, 1, 0)

__version__ = '.'.join(map(str, VERSION))
