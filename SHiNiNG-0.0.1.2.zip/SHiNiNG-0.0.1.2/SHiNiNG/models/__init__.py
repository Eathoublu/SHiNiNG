

__author__ = 'LanYixiao_Eathoublu'


class ShiningBuildInModel(object):

    def __init__(self):

        pass

    def auto(self, auto, language_corpus, language_target, work_path, step_save, tokenize_flag, n_gram, *args, **kwargs):

        # raise NotImplementedError

        pass


class ShiningSubModel(object):

    def __init__(self):

        pass
